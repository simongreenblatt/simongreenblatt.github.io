This ZIP file contains the source code for vlogin, vloginNoLoop, and the injector program with the COOP payload. You can use the following commands to compile the programs:

g++ -no-pie -ggdb -m32 -o vlogin vlogin.cpp
g++ -no-pie -ggdb -m32 -o vloginNoLoop vloginNoLoop.cpp
gcc -no-pie -ggdb -m32 -o injector injector.c

These commands compile the programs in 32-bits, without ASLR, and with debug symbols using the g++ and gcc compilers.
You can use the following command to inject the payload into vloginNoLoop to carry out the COOP attack:

./injector | ./vloginNoLoop