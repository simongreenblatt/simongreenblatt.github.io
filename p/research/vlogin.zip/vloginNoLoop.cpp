/*
 * vloginNoLoop program
 *
 * Simon Greenblatt <scamposg@cs.brown.edu>
 * CSCI2951U: Advanced Topics in Software Security
 * 
 */

#include "iostream"
#include <string.h>

using namespace std;

class User {
public:
    char name[8] = {}; // Usernames are limited to 7 characters (must include the null terminator)
    virtual void printName() = 0;
    virtual void performAction() = 0;
}__attribute__((packed)); // Don't store these objects with padding

class Admin : public User {
public:
    void printName() {
        std::cout << "Admin: " << name << "\n";
    }
    void performAction() {
        std::cout << "Administrator-level action performed\n";
    }
};

class Guest : public User {
public:
   void printName() {
        std::cout << "Guest: " << name << "\n";
    }
    void performAction() {
        std::cout << "Guest-level action performed\n";
    }
};

class UserList {
public:
    int currentUser = 4;
    User *userList[5];

    void printUsers() {
        for (int i = 0; i < 5; i++) {
            userList[i]->printName();
        }
    }
}__attribute__((packed));

// StringWrapperParent and StringWrapper are used for memory alignment purposes
class StringWrapperParent {
public:
    std::string s = "0";

    virtual void nothing() = 0;
};

class StringWrapper : public StringWrapperParent {
    public:
        void nothing() {}
};

int main() {
    // The order in which variables are declared is important
    StringWrapper temp;
    Guest user;
    // Load all the dummy users
    Admin admin;
    memcpy(admin.name, "admin", sizeof("admin"));
    Guest alice;
    memcpy(alice.name, "Alice", sizeof("Alice"));
    Guest bob;
    memcpy(bob.name, "Bob", sizeof("Bob"));
    Guest charlie;
    memcpy(charlie.name, "Charlie", sizeof("Charlie"));
    UserList userList;
    userList.userList[0] = &admin;
    userList.userList[1] = &alice;
    userList.userList[2] = &bob;
    userList.userList[3] = &charlie;
    userList.userList[4] = &user;

    // Load the real user
    std::cout << "Please enter a username: \n";
    std::cin >> temp.s;
    memcpy(user.name, temp.s.data(), temp.s.length()); // Memory corruption vulnerability

    // Main actions
    userList.printUsers();
    userList.userList[userList.currentUser]->performAction();
    return 0;
}